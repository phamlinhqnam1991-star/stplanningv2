import { supabaseAdmin } from "@/lib/supabase-admin";
import type {
  CombinedTimelineModel,
  ProductionStateSnapshot,
  TimelineItem,
} from "./types";

function proposalNo(now = new Date()) {
  const d = now.toISOString().slice(0, 10).replace(/-/g, "");
  const t = now.toISOString().slice(11, 19).replace(/:/g, "");
  return `PP-${d}-${t}`;
}

export async function persistProductionSnapshot(args: {
  snapshot: ProductionStateSnapshot;
  horizonStart?: string | null;
  horizonEnd?: string | null;
  sourceHash?: string | null;
}) {
  const { data, error } = await supabaseAdmin
    .from("planning_production_snapshot")
    .insert({
      snapshot_no: args.snapshot.snapshotId,
      captured_at: args.snapshot.capturedAt,
      horizon_start: args.horizonStart ?? null,
      horizon_end: args.horizonEnd ?? null,
      source_hash: args.sourceHash ?? null,
      snapshot_json: args.snapshot,
      summary_json: args.snapshot.summary,
    })
    .select("id,snapshot_no,captured_at")
    .single();

  if (error) throw error;
  return data;
}

export interface ProposedPlacementInput {
  sourceMode: "EXISTING_UNSCHEDULED" | "NEW_PROPOSED";
  existingBatchId?: number | null;
  mainOperation: string;
  recipeId?: number | null;
  recipeNo?: string | null;
  recipeName?: string | null;
  batchKey?: string | null;
  resourceType?: string | null;
  resourceCode?: string | null;
  loadingStart?: string | null;
  loadingEnd?: string | null;
  processStart?: string | null;
  processEnd?: string | null;
  ndtStart?: string | null;
  ndtEnd?: string | null;
  unloadingStart?: string | null;
  unloadingEnd?: string | null;
  startTime?: string | null;
  endTime?: string | null;
  qty?: number;
  surfaceDm2?: number;
  processMinutes?: number | null;
  jobs: Array<{
    planningJobOperationId: number;
    jobNum: string;
    qty?: number;
    surfaceDm2?: number;
    sequenceNo?: number;
  }>;
}

export async function createProposedPlan(args: {
  snapshotDbId: number;
  whatIfRunId?: number | null;
  scenarioName?: string | null;
  model: CombinedTimelineModel;
  proposedPlacements: ProposedPlacementInput[];
  proposalNo?: string;
  cutoff?: string | null;
}) {
  const no = args.proposalNo || proposalNo();
  const s = args.model.outputSummary;

  const { data: plan, error: planError } = await supabaseAdmin
    .from("planning_proposed_plan")
    .insert({
      proposal_no: no,
      snapshot_id: args.snapshotDbId,
      what_if_run_id: args.whatIfRunId ?? null,
      scenario_name: args.scenarioName ?? null,
      target_dm2: s.targetDm2,
      cutoff_time: args.cutoff ?? null,
      status: "READY",
      already_final_dm2: s.alreadyReachedFinalDm2,
      existing_scheduled_dm2: s.existingScheduledForecastDm2,
      existing_unscheduled_dm2: s.existingUnscheduledForecastDm2,
      existing_plan_dm2: s.existingPlanForecastDm2,
      proposed_dm2: s.proposedAdditionalDm2,
      forecast_dm2: s.totalForecastDm2,
      gap_dm2: s.gapDm2,
      output_ledger_json: args.model.outputLedger,
      timeline_json: args.model.items,
    })
    .select("id,proposal_no,status,created_at")
    .single();

  if (planError) throw planError;

  for (const placement of args.proposedPlacements) {
    const { data: batch, error: batchError } = await supabaseAdmin
      .from("planning_proposed_batch")
      .insert({
        proposed_plan_id: plan.id,
        source_mode: placement.sourceMode,
        existing_batch_id: placement.existingBatchId ?? null,
        main_operation: placement.mainOperation,
        recipe_id: placement.recipeId ?? null,
        recipe_no: placement.recipeNo ?? null,
        recipe_name: placement.recipeName ?? null,
        batch_key: placement.batchKey ?? null,
        resource_type: placement.resourceType ?? null,
        resource_code: placement.resourceCode ?? null,
        loading_start: placement.loadingStart ?? null,
        loading_end: placement.loadingEnd ?? null,
        process_start: placement.processStart ?? null,
        process_end: placement.processEnd ?? null,
        ndt_start: placement.ndtStart ?? null,
        ndt_end: placement.ndtEnd ?? null,
        unloading_start: placement.unloadingStart ?? null,
        unloading_end: placement.unloadingEnd ?? null,
        start_time: placement.startTime ?? null,
        end_time: placement.endTime ?? null,
        qty: placement.qty ?? 0,
        surface_dm2: placement.surfaceDm2 ?? 0,
        process_minutes: placement.processMinutes ?? null,
        status: "PROPOSED",
      })
      .select("id")
      .single();

    if (batchError) throw batchError;

    if (placement.jobs.length) {
      const { error: jobsError } = await supabaseAdmin
        .from("planning_proposed_batch_job")
        .insert(
          placement.jobs.map((job, index) => ({
            proposed_batch_id: batch.id,
            planning_job_operation_id: job.planningJobOperationId,
            job_num: job.jobNum,
            qty: job.qty ?? 0,
            surface_dm2: job.surfaceDm2 ?? 0,
            sequence_no: job.sequenceNo ?? index + 1,
          }))
        );
      if (jobsError) throw jobsError;
    }
  }

  return plan;
}

export function proposedItemsFromTimeline(items: TimelineItem[]) {
  return items.filter(
    (item) =>
      item.state === "PROPOSED_EXISTING_BATCH" ||
      item.state === "PROPOSED_NEW_BATCH"
  );
}
